package com.loginpage.dao;

import com.loginpage.entity.Role;

public interface RoleDao {
    public Role findRoleByName(String theRoleName);
}
