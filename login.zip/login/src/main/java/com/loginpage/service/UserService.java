package com.loginpage.service;

import com.loginpage.entity.User;
import com.loginpage.user.CrmUser;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    User findByUserName(String userName);

    void save(CrmUser crmUser);
}
